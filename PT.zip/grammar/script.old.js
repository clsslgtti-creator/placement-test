// Global variables
let questions = {};
let selectedQuestions = [];
const totalQuestions = 50; // Test has 50 questions
const testDuration = 40 * 60 * 1000; // 40 minutes in milliseconds
let startTimestamp = null;
let timerInterval;
let userAnswers = {};
let isScormMode = false; // Track if we're running in SCORM mode

// DOM elements
const questionsContainer = document.getElementById("questions-container");
const checkAnswersBtn = document.getElementById("check-answers");
const actionsSection = document.querySelector(".actions");
const resultsSection = document.getElementById("results");
const topResultsSection = document.getElementById("top-results");
const scoreElement = document.getElementById("score");
const topScoreElement = document.getElementById("top-score");
const totalQuestionsElement = document.getElementById("total-questions");
const topTotalElement = document.getElementById("top-total");
const timeRemainingElement = document.getElementById("time-remaining");
const topTimeSpentElement = document.getElementById("top-time-spent");
const bottomTimeSpentElement = document.getElementById("bottom-time-spent");
const timerBar = document.getElementById("timer-bar");

// Initialize test variables
function initializeTest() {
  startTimestamp = Date.now();
  userAnswers = {};
  
  // Only initialize SCORM-related data if in SCORM mode
  if (isScormMode && scorm && scorm.connection.isActive) {
    const state = {
      startTime: startTimestamp,
      questionIds: selectedQuestions.map(q => q.id),
      answers: {}
    };
    scorm.set("cmi.suspend_data", JSON.stringify(state));
    scorm.save();
  }
}

// Fetch questions from the JSON file
async function fetchQuestions() {
  try {
    const response = await fetch("questions.json");
    const data = await response.json();

    // Store all questions sets
    questions = {
      set1: data.question_set_1,
      set2: data.question_set_2,
      set3: data.question_set_3,
      set4: data.question_set_4,
    };

    // Select random questions
    selectRandomQuestions();

    // Initialize test state and start timer
    initializeTest();
    
    // Render questions
    renderQuestions();
    
    // Start the timer
    startTimer();
  } catch (error) {
    console.error("Error fetching questions:", error);
    questionsContainer.innerHTML =
      '<p class="error">Failed to load questions. Please refresh the page.</p>';
  }
}

// Select random questions from each set
function selectRandomQuestions() {
  selectedQuestions = [];

  // For each question position, randomly select from one of the four sets
  for (let i = 0; i < totalQuestions; i++) {
    // Select a random set (1-4)
    const sets = ["set1", "set2", "set3", "set4"];
    let selectedSet;
    let questionFromSet;

    // Find a valid question (some sets might have fewer questions)
    do {
      selectedSet = sets[Math.floor(Math.random() * sets.length)];
      // Use modulo to ensure we don't go out of bounds if a set has fewer than 50 questions
      const questionIndex = i % 50; // This ensures we stay within the bounds of each set
      questionFromSet = questions[selectedSet][questionIndex];

      // If this set doesn't have this question, remove it from consideration
      if (!questionFromSet) {
        const setIndex = sets.indexOf(selectedSet);
        if (setIndex > -1) {
          sets.splice(setIndex, 1);
        }
      }
    } while (!questionFromSet && sets.length > 0);

    // If found a valid question, add it to selected questions
    if (questionFromSet) {
      // Clone the question to avoid modifying the original
      const questionCopy = JSON.parse(JSON.stringify(questionFromSet));

      // Shuffle the options
      questionCopy.options = shuffleArray(questionCopy.options);

      // Add to selected questions
      selectedQuestions.push(questionCopy);
    }
  }
}

// Use the shared shuffleArray function from common.js
function shuffleArray(array) {
  // Check if the testUtils object from common.js is available
  if (window.testUtils && window.testUtils.shuffleArray) {
    return window.testUtils.shuffleArray(array);
  } else {
    // Fallback to the local implementation if shared function is not available
    let currentIndex = array.length;
    let temporaryValue, randomIndex;

    // While there remain elements to shuffle
    while (0 !== currentIndex) {
      // Pick a remaining element
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;

      // Swap it with the current element
      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }

    return array;
  }
}

// Render questions to the DOM
function renderQuestions() {
  questionsContainer.innerHTML = "";
  totalQuestionsElement.textContent = selectedQuestions.length;

  selectedQuestions.forEach((question, index) => {
    const questionElement = document.createElement("div");
    questionElement.className = "question-item";
    questionElement.dataset.index = index;

    // Create number badge div
    const numberBadge = document.createElement("div");
    numberBadge.className = "question-number";
    numberBadge.textContent = `${index + 1}`;

    // Create question content container
    const questionContent = document.createElement("div");
    questionContent.className = "question-content";

    // Create question text
    const questionText = document.createElement("p");
    questionText.className = "question-text";
    questionText.textContent = question.question;

    // Add question text to content container
    questionContent.appendChild(questionText);

    // Create options list
    const optionsList = document.createElement("ul");
    optionsList.className = "options";

    question.options.forEach((option, optionIndex) => {
      const optionItem = document.createElement("li");
      optionItem.className = "option";
      optionItem.textContent = option;
      optionItem.dataset.value = option;

      optionItem.addEventListener("click", () =>
        selectOption(index, option, optionItem)
      );

      optionsList.appendChild(optionItem);
    });

    // Add options to content container
    questionContent.appendChild(optionsList);

    // Add number badge and content to question element
    questionElement.appendChild(numberBadge);
    questionElement.appendChild(questionContent);

    questionsContainer.appendChild(questionElement);
  });
}

// Select option
function selectOption(questionIndex, option, optionElement) {
  // Remove selected class from all options in this question
  const questionElement = optionElement.closest(".question-item");
  const options = questionElement.querySelectorAll(".option");
  options.forEach((opt) => opt.classList.remove("selected"));

  // Add selected class to clicked option
  optionElement.classList.add("selected");

  // Save user's answer
  userAnswers[questionIndex] = option;
}

// Start the timer
function startTimer() {
  // In SCORM mode, try to get existing start time
  if (isScormMode && scorm && scorm.connection.isActive) {
    const suspendData = scorm.get("cmi.suspend_data");
    if (suspendData) {
      try {
        const savedData = JSON.parse(suspendData);
        startTimestamp = savedData.startTime;
      } catch (error) {
        console.error("Error parsing suspend data:", error);
      }
    }
  }
  
  // If no start time set (either new test or non-SCORM), set it now
  if (!startTimestamp) {
    startTimestamp = Date.now();
    // If in SCORM mode, save initial state
    if (isScormMode && scorm && scorm.connection.isActive) {
      const initialState = {
        startTime: startTimestamp,
        questionIds: selectedQuestions.map(q => q.id),
        answers: {}
      };
      scorm.set("cmi.suspend_data", JSON.stringify(initialState));
      scorm.save();
    }
  }

  updateTimerDisplay();
  timerInterval = setInterval(updateTimerDisplay, 1000);
}

// Update timer display
function updateTimerDisplay() {
  if (!startTimestamp) return; // Safety check
  
  const now = Date.now();
  const elapsedTime = now - startTimestamp;
  const totalDuration = 40 * 60 * 1000; // 40 minutes in milliseconds
  const remainingTime = Math.max(0, totalDuration - elapsedTime);

  // Calculate minutes and seconds
  const minutes = Math.floor(remainingTime / (60 * 1000));
  const seconds = Math.floor((remainingTime % (60 * 1000)) / 1000);
  timeRemainingElement.textContent = `${minutes
    .toString()
    .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;

  // Calculate percentage for timer bar
  const percentage = (remainingTime / totalDuration) * 100;
  if (timerBar) {
    timerBar.style.width = `${percentage}%`;

    // Change color when time is running low
    if (percentage < 25) {
      timerBar.style.backgroundColor = "var(--danger-color)";
    } else if (percentage < 50) {
      timerBar.style.backgroundColor = "var(--warning-color)";
    }
  }

  // End test if time is up
  if (remainingTime <= 0) {
    endTest();
  }
}

// End the test
function endTest() {
  clearInterval(timerInterval);

  // Hide the check answers button
  if (window.testUtils && window.testUtils.hideElement) {
    window.testUtils.hideElement(actionsSection);
  } else {
    actionsSection.style.display = "none";
  }

  // Hide questions after completion
  if (questionsContainer) {
    questionsContainer.style.display = "none";
  }

  // Calculate time spent on test using startTimestamp
  const endTime = Date.now();
  const timeSpentMs = endTime - startTimestamp;
  const maxDurationMs = 40 * 60 * 1000; // 40 minutes in milliseconds
  const timeSpentSec = Math.min(
    Math.floor(timeSpentMs / 1000),
    maxDurationMs / 1000
  );

  // Format time spent
  const minutes = Math.floor(timeSpentSec / 60);
  const seconds = timeSpentSec % 60;
  const formattedTime = `${minutes.toString().padStart(2, "0")}:${seconds
    .toString()
    .padStart(2, "0")}`;
  const timeSpent = timeSpentSec; // Add this line to define timeSpent

  // Update time spent display
  topTimeSpentElement.textContent = formattedTime;

  // Calculate score and show results
  calculateScore();

  // Save test results to localStorage if shared function is available
  if (window.testUtils && window.testUtils.saveToLocalStorage) {
    window.testUtils.saveToLocalStorage("grammar_test_data", {
      score: scoreElement.textContent,
      totalQuestions: totalQuestionsElement.textContent,
      timeSpent: formattedTime,
      completedDate: new Date().toISOString(),
    });
  }

    // Format time for Google Sheets - need a different format than display format
  const minutesForSheet = Math.floor((timeSpent % 3600) / 60);
  const secondsForSheet = timeSpent % 60;
  const formattedTimeForSheets = `${minutesForSheet
    .toString()
    .padStart(2, "0")}:${secondsForSheet.toString().padStart(2, "0")}`;

  // Get the score from the top score element
  const score = parseInt(topScoreElement.textContent);
  console.log('Score being sent to Google Sheets:', score); // Debug log  // Prepare detailed answer data for Google Sheets
  const detailedAnswers = prepareDetailedAnswerData();

  // Try to submit results to SCORM LMS if available
  if (scorm && scorm.connection.isActive) {
    submitScormResults();
  } else {
    // If SCORM is not available, still send data to Google Sheets
    console.log(
      "SCORM not available, sending results directly to Google Sheets"
    );
    sendResultsToGoogleSheet(
      "",
      score,
      detailedAnswers,
      formattedTimeForSheets
    );
  }
}

// Calculate score and show results
function calculateScore() {
  let score = 0;
  console.log('Calculating score...'); // Debug log

  // Log answers for debugging
  console.log('User answers:', userAnswers);
  console.log('Correct answers:', selectedQuestions.map(q => q.answer));

  Object.keys(userAnswers).forEach((index) => {
    console.log(`Question ${index}:`, {
      userAnswer: userAnswers[index],
      correctAnswer: selectedQuestions[index].answer,
      isCorrect: userAnswers[index] === selectedQuestions[index].answer
    });
    if (userAnswers[index] === selectedQuestions[index].answer) {
      score++;
    }
  });

  console.log('Final score:', score); // Debug log

  // Update score display
  topScoreElement.textContent = score;
  topTotalElement.textContent = selectedQuestions.length;

  // Show only top results section
  if (topResultsSection) {
    topResultsSection.classList.remove("hidden");
    topResultsSection.style.display = "block";
  }
  // Hide bottom results section
  if (resultsSection) {
    resultsSection.style.display = "none";
  }

  // Disable all options and hide the complete button after test completion
  document.querySelectorAll(".option").forEach((option) => {
    option.style.pointerEvents = "none";
  });
  if (actionsSection) {
    actionsSection.style.display = "none";
  }

  // Scroll to top to show results
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });

  // No attempt tracking needed since only one attempt is allowed

  // Disable all options
  const options = document.querySelectorAll(".option");
  options.forEach((option) => {
    option.style.pointerEvents = "none";
  });

  // Scroll to top using shared function if available
  if (window.testUtils && window.testUtils.scrollToElement) {
    window.testUtils.scrollToElement(document.body);
  } else {
    // Fallback to local implementation
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  // Show completion notification
  showNotification(
    `Test completed! Your score: ${score}/${selectedQuestions.length}`,
    "success"
  );
}

// Prepare detailed answer data for reporting
function prepareDetailedAnswerData() {
  // Create a compact string representation of answers
  const answersById = {};

  selectedQuestions.forEach((question, index) => {
    if (!question.id) return; // Skip if no ID

    const userAnswer = userAnswers[index] || "N/A";
    const isCorrect = userAnswer === question.answer;

    // Store in format "id: answer (correct/incorrect)"
    answersById[question.id] = {
      answer: userAnswer,
      correct: isCorrect,
    };
  });

  return answersById;
}

// SCORM-related functions
let scorm;

// Initialize SCORM connection
async function initScorm() {
  try {
    scorm = pipwerks.SCORM;
    console.log("Initializing SCORM connection...");
    const connected = scorm.init();

    if (connected) {
      isScormMode = true;
      console.log("SCORM connection established successfully");

      // Check lesson status
      const lessonStatus = scorm.get("cmi.core.lesson_status");
      if (lessonStatus === "completed") {
        console.log("Test already completed in SCORM. No retakes allowed.");
        showCompletedState();
        return connected;
      }

      // Load saved state if it exists
      const suspendData = scorm.get("cmi.suspend_data");
      if (suspendData) {
        try {
          const savedData = JSON.parse(suspendData);
          console.log("Found saved state:", savedData);
          
          if (savedData.completed) {
            console.log("Test was completed previously");
            showCompletedState();
            return connected;
          }

          if (savedData.startTime && savedData.questionIds && savedData.answers) {
            console.log("Restoring previous session");
            startTimestamp = savedData.startTime;
            userAnswers = savedData.answers;
            
            // Load questions first if needed
            if (!questions || Object.keys(questions).length === 0) {
              await fetchQuestionsById();
            }
            
            // Reconstruct selected questions from IDs
            selectedQuestions = savedData.questionIds.map(id => {
              const [set, num] = id.split('_');
              return questions[`set${set}`][num - 1];
            }).filter(Boolean);

            if (selectedQuestions.length === totalQuestions) {
              console.log("Successfully restored previous session");
              renderQuestions();
              restoreUserAnswers();
              startTimer();
              return connected;
            }
          }
        } catch (error) {
          console.error("Error parsing suspend data:", error);
        }
      }

      // No valid saved state or error in restore, start fresh
      scorm.set("cmi.core.lesson_status", "incomplete");
      console.log("Starting new session in SCORM");
      return connected;
    }
  } catch (error) {
    console.log("SCORM not available:", error);
  }

  // If we reach here, run in non-SCORM mode
  console.log("Running in test mode - reloads will start fresh");
  isScormMode = false;
  return false;
}

// Show completed state
function showCompletedState() {
  const score = scorm.get("cmi.core.score.raw");
  document.body.innerHTML = `
    <div class="container">
      <div class="score-board">
        <h1>Test Completed</h1>
        <p>You have already completed this test.</p>
        <div class="score-content">
          <div class="score-value">Score: ${score}/50</div>
        </div>
      </div>
    </div>
  `;
}

// Restore user's previous answers
function restoreUserAnswers() {
  Object.keys(userAnswers).forEach(index => {
    const answer = userAnswers[index];
    const questionElement = document.querySelector(`.question-item[data-index="${index}"]`);
    if (questionElement) {
      const options = questionElement.querySelectorAll('.option');
      options.forEach(option => {
        if (option.dataset.value === answer) {
          option.classList.add('selected');
        }
      });
    }
  });
}

// Send results to Google Spreadsheet
function sendResultsToGoogleSheet(name, score, answers, timeSpent) {
  // The URL should be replaced with your Google Apps Script Web App URL
  const GOOGLE_SHEET_URL =
    "https://script.google.com/macros/s/AKfycbxZKrhA-wXc_7ymR1wOwX-W_GzyMZwXqj3ORdvJ84QCibx2gt9_D5FvicLJdrXj36nJOQ/exec";

  // Try to get student information from SCORM LMS
  let studentName = "Anonymous";
  let studentId = "";

  if (scorm && scorm.connection.isActive) {
    // Try to get student name from various SCORM fields
    studentName =
      scorm.get("cmi.core.student_name") ||
      scorm.get("cmi.student_name") ||
      scorm.get("cmi.learner_name") ||
      name ||
      "Anonymous";

    // Try to get student ID
    studentId =
      scorm.get("cmi.core.student_id") ||
      scorm.get("cmi.student_id") ||
      scorm.get("cmi.learner_id") ||
      "";
  } else if (name) {
    studentName = name;
  }

  // If no name is available from SCORM, check if we should prompt the user
  if (studentName === "Anonymous" && !name) {
    // Ask user for their name if not in SCORM
    const userName = prompt("Please enter your name for the results:", "");
    if (userName && userName.trim() !== "") {
      studentName = userName.trim();
    }
  }

  // Prepare data to send
  const data = {
    testType: "Grammar Test",
    name: studentName,
    studentId: studentId,
    score: score,
    totalQuestions: selectedQuestions.length,
    timeSpent: timeSpent,
    date: new Date().toISOString(),
    answers: answers, // This should be an array of objects from prepareDetailedAnswerData()
  };

  console.log("Sending results to Google Sheet:", data);

  // Log data for debugging
  console.log("Sending data to Google Sheet:", data);

  // Convert answers to a compact string format
  let answersString = "";
  if (data.answers && typeof data.answers === "object") {
    // Format as "id:answer(✓/✗),id2:answer(✓/✗)"
    const answerParts = [];

    for (const id in data.answers) {
      if (data.answers.hasOwnProperty(id)) {
        const answerObj = data.answers[id];
        const statusMark = answerObj.correct ? "(✓)" : "(✗)";
        answerParts.push(`${id}:${answerObj.answer}${statusMark}`);
      }
    }

    // Join with commas
    answersString = answerParts.join(", ");
  }

  // Replace the answers object with the string representation
  data.answers = answersString;

  // Send data to Google Sheet
  fetch(GOOGLE_SHEET_URL, {
    method: "POST",
    mode: "no-cors",
    body: JSON.stringify(data),
    headers: { "Content-Type": "application/json" },
  })
    .then((res) => res.text())
    .then((res) => {
      console.log("Google Sheet response:", res);

      // Show success notification
      showNotification("Results submitted successfully!", "success");
    })
    .catch((err) => {
      console.error("Error sending results to Google Sheet:", err);

      // Show error notification
      showNotification("Failed to submit results to server", "error");
    });
}

// Submit results to SCORM LMS
function submitScormResults() {
  if (!scorm || !scorm.connection.isActive) {
    console.warn("SCORM connection is not active, cannot submit results");
    return;
  }

  try {
    // Get current score from the display
    const score = parseInt(topScoreElement.textContent);
    console.log('Submitting score to SCORM:', score); // Debug log

    // Set the raw score (not percentage)
    scorm.set("cmi.core.score.raw", score);
    scorm.set("cmi.core.score.min", "0");
    scorm.set("cmi.core.score.max", "50");

    // Calculate session time
    const timeSpent = totalTime - timeRemaining;
    const hours = Math.floor(timeSpent / 3600);
    const minutes = Math.floor((timeSpent % 3600) / 60);
    const seconds = timeSpent % 60;
    const scormTime = `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;

    // Format time for display and Google Sheets
    const formattedTime = `${minutes.toString().padStart(2, "0")}:${seconds
      .toString()
      .padStart(2, "0")}`;

    // Set session time
    scorm.set("cmi.core.session_time", scormTime);

    // Always set lesson status to "completed" when test is submitted
    scorm.set("cmi.core.lesson_status", "completed");
    console.log("SCORM test marked as completed");

    // Create a minimal version storing just question IDs and user answers
    const answersById = {};

    // Convert userAnswers to use question IDs
    Object.keys(userAnswers).forEach((index) => {
      const questionId = selectedQuestions[index].id;
      if (questionId) {
        answersById[questionId] = userAnswers[index];
      }
    });

    // Store selected question IDs (for retrieval later)
    const selectedQuestionIds = selectedQuestions.map((q) => q.id);

    // Create data object to save (minimal version)
    const dataToSave = {
      questionIds: selectedQuestionIds,
      answers: answersById,
      score: score,
      totalQuestions: totalQuestions,
      timeSpent: formattedTime,
      completedDate: new Date().toISOString(),
    };

    // Convert to string and log size
    const jsonData = JSON.stringify(dataToSave);
    console.log("Suspend data size (bytes):", jsonData.length);

    // Check if the data is too large for some SCORM implementations
    if (jsonData.length > 4000) {
      console.warn(
        `SCORM data is ${jsonData.length} bytes, which may exceed limits for some SCORM 1.2 implementations`
      );

      // Try to reduce the data size if it's too large
      if (jsonData.length > 64000) {
        // Absolute maximum for most implementations
        // Create an even more compact version with minimal data
        const minimalData = {
          score: score,
          totalQuestions: totalQuestions,
          attemptCount: attemptCount,
          completedDate: new Date().toISOString(),
        };
        console.warn("Data exceeds safe limits. Saving minimal data only.");
        scorm.set("cmi.suspend_data", JSON.stringify(minimalData));
      } else {
        // Try with the original data but warn about potential issues
        scorm.set("cmi.suspend_data", jsonData);
      }
    } else {
      // Data size is acceptable, proceed normally
      scorm.set("cmi.suspend_data", jsonData);
    }

    // Save all data to the LMS
    const success = scorm.save();
    console.log("SCORM save result:", success);

    // Verify data was saved properly by reading it back
    if (success) {
      const savedSuspendData = scorm.get("cmi.suspend_data");
      if (!savedSuspendData) {
        console.warn(
          "SCORM data was supposedly saved successfully but suspend_data is empty!"
        );
      } else {
        console.log("SCORM data verified - suspend_data is populated");
      }
    }

    // Get detailed answers for Google Sheets
    const detailedAnswers = prepareDetailedAnswerData();

    // Always send data to Google Sheets, regardless of SCORM success
    sendResultsToGoogleSheet("", score, detailedAnswers, formattedTime);

    if (success) {
      console.log(
        `SCORM data successfully saved. Score: ${scorePercentage}%, Time: ${scormTime}`
      );
    } else {
      console.error("Failed to save SCORM data");
    }
  } catch (error) {
    console.error("Error submitting SCORM results:", error);
  }
}

// Function to clean up and show completion message after test completion
async function cleanupTest() {
  // Clear interval and container
  clearInterval(timerInterval);
  questionsContainer.innerHTML = "";
  
  // If in SCORM mode, mark as completed
  if (isScormMode && scorm && scorm.connection.isActive) {
    scorm.set("cmi.core.lesson_status", "completed");
    scorm.save();
  }
  
  // Create and show completion message
  const messageDiv = document.createElement("div");
  messageDiv.className = "message-board";
  
  if (isScormMode) {
    messageDiv.innerHTML = "<h2>Test Complete</h2><p>Your responses have been recorded in the LMS.</p>";
  } else {
    messageDiv.innerHTML = `
      <h2>Test Complete</h2>
      <p>Your responses have been recorded. Since this is running in test mode, you can reload the page to start a new attempt.</p>
    `;
  }
  
  questionsContainer.appendChild(messageDiv);
}

// Save current answers to SCORM
// Function to save an answer
function saveAnswer(questionIndex, answer) {
  userAnswers[questionIndex] = answer;

  // Only save to SCORM if in SCORM mode
  if (isScormMode && scorm && scorm.connection.isActive) {
    try {
      // Save only question IDs and answers to minimize SCORM storage
      const state = {
        startTime: startTimestamp,
        questionIds: selectedQuestions.map(q => q.id),
        answers: userAnswers
      };
      
      scorm.set("cmi.suspend_data", JSON.stringify(state));
      scorm.save();
    } catch (error) {
      console.error("Failed to save answer to SCORM:", error);
    }
  }
}

// Function to complete the test
function completeTest() {
  clearInterval(timerInterval);
  
  // Calculate score
  let score = 0;
  Object.keys(userAnswers).forEach((index) => {
    if (userAnswers[index] === selectedQuestions[index].answer) {
      score++;
    }
  });
  
  // Show score
  const percentage = Math.round((score / selectedQuestions.length) * 100);
  questionsContainer.innerHTML = `
    <div class="message-board">
      <h2>Test Complete</h2>
      <p>Your score: ${score} out of ${selectedQuestions.length} (${percentage}%)</p>
    </div>
  `;
  
  // If in SCORM mode, save completion
  if (isScormMode && scorm && scorm.connection.isActive) {
    scorm.set("cmi.core.score.raw", percentage);
    scorm.set("cmi.core.lesson_status", "completed");
    scorm.set("cmi.suspend_data", ""); // Clear suspend data since test is complete
    scorm.save();
  }
}

// Display the appropriate message based on SCORM mode
function showCompletionMessage() {
  // Clear container
  questionsContainer.innerHTML = "";
  
  // Create message div
  const messageDiv = document.createElement("div");
  messageDiv.className = "message-board";
  
  if (isScormMode) {
    messageDiv.innerHTML = "<h2>Test Complete</h2><p>Your responses have been recorded in the LMS.</p>";
  } else {
    messageDiv.innerHTML = `
      <h2>Test Complete</h2>
      <p>Your responses have been recorded. Since this is running in test mode, you can reload the page to start a new attempt.</p>
    `;
  }
  
  questionsContainer.appendChild(messageDiv);
}

// Function to handle SCORM state save
function handleScormData() {
  if (scorm && scorm.connection.isActive) {
    // Save the current test state
    const testState = {
      startTime: startTime,
      answers: userAnswers,
    };
    scorm.set("cmi.suspend_data", JSON.stringify(testState));
    scorm.save();
  }
}

// Show notification
function showNotification(message, type = 'success') {
  // Remove any existing notifications
  const existingNotification = document.querySelector('.notification');
  if (existingNotification) {
    existingNotification.remove();
  }

  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  
  // Add icon based on type
  const icon = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
  
  notification.innerHTML = `
    <i class="${icon}"></i>
    ${message}
  `;

  // Add to document
  document.body.appendChild(notification);

  // Remove after animation
  setTimeout(() => {
    notification.remove();
  }, 5000);
}

// Close SCORM connection
function closeScorm() {
  if (scorm && scorm.connection.isActive) {
    scorm.quit();
    console.log("SCORM connection terminated");
  }
}

// Handle window unload event to ensure SCORM connection is properly closed
window.addEventListener("beforeunload", closeScorm);

// Event listeners
document.addEventListener("DOMContentLoaded", () => {
  console.log("Grammar test page loaded");

  // Initialize SCORM connection
  const scormConnected = initScorm();
  console.log("SCORM connection initialized:", scormConnected);

  // Only fetch questions and start the test if we're not showing previous results
  // (which happens in the initScorm function if applicable)
  if (!window.showingPreviousResults) {
    console.log("Starting new test session");

    // Fetch questions and start the test
    fetchQuestions();

    // Add event listener for check answers/complete button
    checkAnswersBtn.addEventListener("click", endTest);
  }
});

// This function fetches the questions from questions.json and
// returns the original questions with correct answers by ID
async function fetchQuestionsById() {
  try {
    const response = await fetch("questions.json");
    const data = await response.json();

    // Create a map of questions by ID
    const questionsById = {};

    // Process all question sets
    [
      "question_set_1",
      "question_set_2",
      "question_set_3",
      "question_set_4",
    ].forEach((setKey) => {
      if (data[setKey] && Array.isArray(data[setKey])) {
        data[setKey].forEach((question) => {
          if (question.id) {
            questionsById[question.id] = question;
          }
        });
      }
    });

    return questionsById;
  } catch (error) {
    console.error("Error fetching questions by ID:", error);
    return {};
  }
} 
